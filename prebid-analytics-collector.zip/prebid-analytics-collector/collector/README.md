# Collector

Written in GO and using only the most efficient libraries, Collector
aims to be extremely lightweight, efficient and highly scalable web
service, whose purpose is to collect pre-bid data across all of
NewsCorp's publications.

As of this writing the service is configured to
run on Google AppEngine Flex, but can be very easily modified to run in
any conceivable environment/OS.

## How it Works
![Collector Diagram][d]

[d]: diagrams/collector.png "Collector Diagram"
1. Java Script tag performs series of parallel
[prebid](http://prebid.org/overview/intro.html) auctions against our
partners, which are a bunch of http requests
2. Every part of the bid request and response is serialized on the
client side using Java Script implementation of
[Protobuf3](https://github.com/dcodeIO/ProtoBuf.js/) using [this schema](appnexus.proto)
3. Serialized objects are then posted to this collector service served
at https://log.ncaudienceexchange.com/pb
4. PrebidHandler receives bytes into byte array from the body of the
post and pushed it onto a buffered channel
6. On a separate thread, in a tight loop, runs 'LogData' function which
listens to the channel and operates on GcsGzFileRoller, doing one of 2
possible things:
    1. Either call for a close of current file stream, upon NOT
    receiving any messages from the channel due to inactivity (within 60
    seconds) OR
    2. Pull in a new message from the channel and submit it to
    GcsGzFileRoller.WriteGZ(message) function, which results in:
        1. Deserialize byte array from Protobuf3 into JSON
        2. Check if stream is open, if not open up a new one to new
        file via GcsGzFileRoller.NextGZ()
        3. If the file we are streaming to is older than the current
        hour, or compressed bytes written out are >= 524288000 (500mb),
        close the file stream and start a new one by calling
        GcsGzFileRoller.NextGZ()
        4. Write message bytes to a buffer of 4096 bytes
        5. Upon fill up buffer unloads the bytes it accumulated onto
        gzip stream for compression
        6. gzip stream flushes compressed bytes to google storage stream
        through GcsGzFileRoller.Write(buf []byte) wrapper function (an
        implementation of io.Writer interface by GcsGzFileRoller),
        whose purpose is also to keep an atomic count of compressed
        bytes written to the stream.
        7. Increment count of uncompressed bytes written to file
        8. Increment records count for records written to file

## Local Environment

### Requirements

1. [Latest Golang >= 1.13.6 environment](https://golang.org/doc/install)
    1. download https://dl.google.com/go/go1.13.6.darwin-amd64.tar.gz
    2. unizip the archive into /usr/local
       tar -C /usr/local -xzf go$VERSION.$OS-$ARCH.tar.gz
    3. Add /usr/local/go/bin to the PATH environment variable
    4. Add below environment variables
       export GOOS=darwin
       export GOARCH=386
    5. 

2. IDE of your choice best suitable for Go development, suggestions:
    1. [IntelliJ](https://www.jetbrains.com/idea/) - install Go plugin (and optionally Go app engine)
    2. [GoLand](https://www.jetbrains.com/go/) - same as option 1 above, but already prefabbed
    3. [liteide](https://github.com/visualfc/liteide)
    4. [Visual Studio Code](https://code.visualstudio.com/)
    5. [Atom](https://ide.atom.io/)
    6. [Vim](https://www.vim.org/)
    7. [GoClipse](https://goclipse.github.io/)

### Local Setup

1. Make sure to have your `collector` folder within the GOPATH, like so
`$GOPATH/src/collector` - easiest way to do that is via symlink. If
your collector folder is located in
`/home/youruser/work/newsiq/collector` and your GOPATH is
`/home/youruser/go`, then your symlink creation shall be:
```bash
$ ln -s "/home/youruser/work/newsiq/collector" "/home/youruser/go/src/collector"
```
2. Because this code is configured to run on Google AppEngine Flex,
there are a few limitations/awkwardness to running it locally
(mostly due to poor library design on Google's side). The following
Options are available:
    1. Run locally w/o write to GS. Make below changes within main.go:
        1. comment out init() function entirely
        2. within main() function comment out `appengine.Main()` and
        uncomment `RunService(":8080")`
        3. now either run via your IDE, or in terminal:
        ```
        $ go run main.go
        ```
        open up `http://localhost:8080` to see a quick status
        >Please Note: writing to google storage shall fail, due to
        shortcoming of the api libraries (there are some hacks to ge them
        to write to GS which need looking into via Google's Git repo)

    2. Follow Google instructions for
    [Go Development Server](https://cloud.google.com/appengine/docs/standard/go/tools/using-local-server)
    3. Deploy/Create App into `newscorp-newsiq-dev` - AppEngine allows
    you to run multiple versions of your code at the same time.

## Making Changes to Schema
There will likely come a time when you need to add, remove or make adjustments
to the columns or entities (hierarchies) within [this schema](appnexus.proto), to do that:
1. Following [Protobuf3 schema standards and using its types](https://developers.google.com/protocol-buffers/docs/proto3)
make your changes
2. Install Protobuf:

    Mac OS X
    If you have Homebrew (which you can get from https://brew.sh), just run:

        $ brew install protobuf
    If you see any error messages, run brew doctor, follow any recommended fixes, and try again. If it still fails, try instead:

        $ brew upgrade protobuf
3. Install [protoc-gen-go](https://github.com/golang/protobuf) like so:

        $ go get -d -u github.com/golang/protobuf/protoc-gen-go
4. In order to make sure protoc-gen-go is in the path do the following (be patient, this may take a while):

        $ cd $GOPATH
        $ go get ./...
5. Now check that protoc-gen-go is in your path by typing the command into command line and running it:

        $ protoc-gen-go
6. Now cd back into collector and generate a serializer from you changed schema like so:

        $ cd $GOPATH/src/collector
        $ protoc --go_out=. *.proto
7. The last command should have generated an `appnexus.pb.go` file in the root of collector directory:

    1. open it and copy the code into clipboard
    2. now open `serialize/appnexus.pb.go` and replace all code in there with the one in clipboard, leaving only proper package name
        >package serialize
    3. delete the generated, root-based `appnexus.pb.go`
8. Now that we are all set with the protobuf deserializer we need to
make sure we've got a super efficient [ffjson](https://github.com/pquerna/ffjson)
9. delete `serialize/appnexus.pb_ffjson.go`
10. generate a new one like so:

        $ ffjson $GOPATH/src/collector/serialize/appnexus.pb.go
11. make sure to adjust package name to:
       >package serialize
## Deployment
Deploying the changes is extremely easy
1. Make sure your account has permission and that you have [gcloud](https://cloud.google.com/sdk/gcloud/reference/app/)
installed
2. Make sure you are using appropriate project environment -
`newscorp-newsiq-dev` is dev, whereas prod is `newscorp-newsiq`. Do the
following:
    1. Check which environment you're in
        ```
        $ gcloud projects list
        ```
    2. Switch to the environment you want like so:
        ```
        $ gcloud config set project newscorp-newsiq-dev
        ```
3. Deploy using the following command in the root of collector
folder:
    ```
    $ gcloud app deploy app.yaml
    ```
    Monitor deployment at https://console.cloud.google.com/appengine/versions
    >Rolling back is very easy, while using web console (link above),
    Select last version (or any) and hit Start, select the current and
    hit Stop (you can also delete it after).