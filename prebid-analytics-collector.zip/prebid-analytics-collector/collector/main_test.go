package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"prebid_collector/serialize"
	"strings"
	"testing"

	"github.com/golang/protobuf/proto"
)

/*
Test conversion of JSON into Protobuf, Post to handler - resulting in Protobuf into JSON,
which should now be equal to the original to pass the test.
*/
// var _ = func() (_ struct{}) {
// 	Env = "dev"
// 	return
// }()

// func TestPrebidHandler(t *testing.T) {
// 	payload := &serialize.LogPrebidEvents{}
// 	payload_dest := &serialize.LogPrebidEvents{}

// 	raw, err := ioutil.ReadFile("./main_test.json") //<-don't mess with json file content, no indents!
// 	json.Unmarshal(raw, payload)
// 	payload_src_byte := []byte(fmt.Sprintf("%v", payload))
// 	pb, _ := proto.Marshal(payload)
// 	r := bytes.NewReader(pb)

// 	req, err := http.NewRequest("POST", "/pb/", r)
// 	if err != nil {
// 		t.Fatal(err)
// 	}
// 	logCh := make(chan PostPayloadChannel, 1111)
// 	rr := httptest.NewRecorder()
// 	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
// 		PrebidHandler(w, r, httprouter.Params{}, logCh)
// 	})
// 	handler.ServeHTTP(rr, req)
// 	select {
// 	case incoming := <-logCh:
// 		proto.Unmarshal(incoming.msg, payload_dest)
// 		payload_dest_byte := []byte(fmt.Sprintf("%v", payload_dest))
// 		if !bytes.Equal(payload_dest_byte, payload_src_byte) {
// 			t.Errorf("Handler produced JSON that is different from the orignal")
// 		}
// 	case <-time.After(time.Nanosecond * 1):
// 		t.Errorf("Taking too long, something is wrong")
// 	}
// }

// func TestVerifyFields(t *testing.T) {
// 	payload := &serialize.LogPrebidEvents{}
// 	var isPrebidAuctionIdValid bool = true

// 	raw, err := ioutil.ReadFile("./main_test.json")
// 	if err != nil {
// 		t.Fatal(err)
// 	}
// 	json.Unmarshal(raw, payload)

// 	isRecordValid := VerifyFields(payload) // max value for timestamp 9223372036854775807(base 10, 64bits); beyond which it should result in error

// 	if (*payload).Timestamp > 9223372036854775807 && isRecordValid {
// 		t.Errorf("VerifyFields Function has failed. It has parsed the wrong timestamp value %v ", (*payload).Timestamp)
// 	}

// 	for _, element := range (*payload).Auctions {
// 		if (*element).PrebidAuctionId == "" {
// 			isPrebidAuctionIdValid = false
// 			break
// 		}
// 	}

// 	if isPrebidAuctionIdValid == false && isRecordValid {
// 		t.Errorf("VerifyFields Function has failed. It has parsed the empty PrebidAuctionId ")
// 	}

// }

//TODO: Refactor to Mock client *storage.Client and performance test GcsGzFileRoller

/*
This is a quick end point loader, will run indefinitely
*/
//func TestEndpoint(t *testing.T) {
//	url := "https://newscorp-newsiq-dev.appspot.com/pb/"
//	payload := &serialize.LogPrebidEvents{}
//
//	raw, err := ioutil.ReadFile("./main_test.json")
//	if err != nil {
//		t.Errorf(err.Error())
//		return
//	}
//
//	json.Unmarshal(raw, payload)
//	pb, _ := proto.Marshal(payload)
//	r := bytes.NewReader(pb)
//
//	for {
//		r.Reset(pb)
//		req, err := http.NewRequest("POST", url, r)
//		client := &http.Client{}
//
//		resp, err := client.Do(req)
//
//		// Loop through headers
//		for name, headers := range resp.Header {
//			name = strings.ToLower(name)
//			for _, h := range headers {
//				println(fmt.Sprintf("%v: %v", name, h))
//			}
//		}
//
//		if err != nil {
//			panic(err)
//		}
//		fmt.Println(resp.Status)
//		//time.Sleep(time.Second * 2)
//	}
//}

func TestEndpointBad(t *testing.T) {
	url := "https://newscorp-newsiq-dev.appspot.com/pb/"
	payload := &serialize.LogPrebidEventsBad{}

	raw, err := ioutil.ReadFile("./main_test.json")
	if err != nil {
		t.Errorf(err.Error())
		return
	}

	json.Unmarshal(raw, payload)
	pb, _ := proto.Marshal(payload)
	r := bytes.NewReader(pb)

	for {
		r.Reset(pb)
		req, err := http.NewRequest("POST", url, r)
		client := &http.Client{}

		resp, err := client.Do(req)

		// Loop through headers
		for name, headers := range resp.Header {
			name = strings.ToLower(name)
			for _, h := range headers {
				println(fmt.Sprintf("%v: %v", name, h))
			}
		}

		if err != nil {
			panic(err)
		}
		fmt.Println(resp.Status)
		//time.Sleep(time.Second * 2)
	}
}
