package main

import (
	"bufio"
	"compress/gzip"
	b64 "encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"prebid_collector/serialize"
	"sort"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"cloud.google.com/go/storage"
	"github.com/golang/protobuf/proto"
	"github.com/julienschmidt/httprouter"
	"github.com/pquerna/ffjson/ffjson"
	"golang.org/x/net/context"
	"google.golang.org/appengine"
	"google.golang.org/appengine/log"
)

// since bucket names are not defined using a specific naming convention
// bucket names are hardcoded for PROD and DEV
// bucket name for the environment will be deduced using the value for PREBID_ENV variable

var bucketNameProd string = "nchq-move-prod-prebid-stage-bq"
var Env = os.Getenv("PREBID_ENV")

var NewLineBytes = len([]byte("\n"))

// variables for constructing JSON message in http.ResponseWriter in the GET request

var validPrebidRecordsKeyName = []byte("{\n\"validPrebidRecords\":")
var invalidPrebidRecordsKeyName = []byte(",\n\"invalidPrebidRecords\":")
var invalidPrebidProtobufRecordsKeyName = []byte(",\n\"invalidPrebidProtobufRecords\":")
var chanSizeKeyName = []byte(",\n\"currentChannelLength\":")
var jsonMsgEnder = []byte("\n}")

type PostPayloadChannel struct {
	msg        []byte
	reqAttrMap *map[string]string
	ctx        context.Context
}

// func init() {
// 	fmt.Println(Env)
// 	if Env == "prod" {
// 		bucketName = bucketNameProd
// 		RunService("")
// 	} else if Env == "dev" {
// 		bucketName = bucketNameDev
// 		RunService("")
// 	}
// }

func main() {
	appengine.Main()
	RunService(":8080")
}

func RunService(port string) {
	router := httprouter.New()

	ctx := appengine.BackgroundContext()
	logCh := make(chan *PostPayloadChannel, 1111)
	client, err := storage.NewClient(ctx)
	bucket := bucketNameProd
	if err != nil {
		log.Errorf(ctx, "failed to create client: %v", err)
		return
	}

	roller := &GcsGzFileRoller{
		client:        client,
		bucket:        bucket,
		ctx:           ctx,
		fileNameTmplt: "nchq-prebid-logs/dt=%s/%s-%s-%v.json.gz",
		instanceId:    os.Getenv("GAE_INSTANCE"),
	}

	badRecordsRoller := &GcsGzFileRoller{
		client:        client,
		bucket:        bucket,
		ctx:           ctx,
		fileNameTmplt: "nchq-prebid-badrecords-logs/dt=%s/%s-%s-%v.json.gz",
		instanceId:    os.Getenv("GAE_INSTANCE"),
	}

	badRecordsRollerProtobuf := &GcsGzFileRoller{
		client:        client,
		bucket:        bucket,
		ctx:           ctx,
		fileNameTmplt: "nchq-prebid-badrecords-protobuf-logs/dt=%s/%s-%s-%v.json.gz",
		instanceId:    os.Getenv("GAE_INSTANCE"),
	}

	go LogData(logCh, roller, badRecordsRoller, badRecordsRollerProtobuf)

	router.POST("/pb", func(w http.ResponseWriter, r *http.Request, rp httprouter.Params) {
		PrebidHandler(w, r, rp, logCh)
	})
	router.POST("/pb/", func(w http.ResponseWriter, r *http.Request, rp httprouter.Params) {
		PrebidHandler(w, r, rp, logCh)
	})
	router.GET("/", func(w http.ResponseWriter, r *http.Request, rp httprouter.Params) {
		w.Header().Add("Content-Type", "text/json;charset=UTF-8")
		prebidProcessingSummary := []byte{}
		validRecordsSummary := roller.GetStats()
		invalidRecordsSummary := badRecordsRoller.GetStats()
		invalidProtobufRecordsSummary := badRecordsRollerProtobuf.GetStats()

		mapStrStr := make(map[string]string)
		json.Unmarshal(validRecordsSummary, &mapStrStr)
		validRecordsSummary = []byte(ConstructDict(mapStrStr))

		json.Unmarshal(invalidRecordsSummary, &mapStrStr)
		invalidRecordsSummary = []byte(ConstructDict(mapStrStr))

		json.Unmarshal(invalidProtobufRecordsSummary, &mapStrStr)
		invalidProtobufRecordsSummary = []byte(ConstructDict(mapStrStr))

		prebidProcessingSummary = append(prebidProcessingSummary, validPrebidRecordsKeyName...)
		prebidProcessingSummary = append(prebidProcessingSummary, validRecordsSummary...)
		prebidProcessingSummary = append(prebidProcessingSummary, invalidPrebidRecordsKeyName...)
		prebidProcessingSummary = append(prebidProcessingSummary, invalidRecordsSummary...)
		prebidProcessingSummary = append(prebidProcessingSummary, invalidPrebidProtobufRecordsKeyName...)
		prebidProcessingSummary = append(prebidProcessingSummary, invalidProtobufRecordsSummary...)
		prebidProcessingSummary = append(prebidProcessingSummary, chanSizeKeyName...)
		prebidProcessingSummary = append(prebidProcessingSummary, []byte(strconv.Itoa(len(logCh)))...)
		prebidProcessingSummary = append(prebidProcessingSummary, jsonMsgEnder...)
		w.Write(prebidProcessingSummary)
	})
	if port != "" {
		http.ListenAndServe(port, router)
		return
	}
	http.Handle("/", router)
}

func LogData(c <-chan *PostPayloadChannel, f *GcsGzFileRoller, brf *GcsGzFileRoller, brfProtobuf *GcsGzFileRoller) {
	defer f.CloseCurrentGZ()
	defer f.client.Close()
	defer brf.CloseCurrentGZ()
	defer brf.client.Close()
	defer brfProtobuf.CloseCurrentGZ()
	defer brfProtobuf.client.Close()
	for {
		select {
		case incoming := <-c:
			f.WriteGZ(incoming, brf, brfProtobuf)
		case <-time.After(time.Second * 60): //<-close stream after 60 seconds of inactivity
			if f.isStreaming {
				f.CloseCurrentGZ()
				log.Infof(f.ctx, "closing '%s' stream due to inactivity", f.filePathAndName)
			}
			if brf.isStreaming {
				brf.CloseCurrentGZ()
				log.Infof(f.ctx, "closing '%s' stream due to inactivity", brf.filePathAndName)
			}
			if brfProtobuf.isStreaming {
				brfProtobuf.CloseCurrentGZ()
				log.Infof(f.ctx, "closing '%s' stream due to inactivity", brfProtobuf.filePathAndName)
			}
		}
	}
}

func TimeTrack(ctx context.Context, c chan *PostPayloadChannel, start time.Time, name string) {
	elapsed := time.Since(start)
	took := elapsed.Nanoseconds() / 1000
	if took > 500 {
		log.Warningf(ctx, "%s took %dms currentChannelLength: %v", name, took, len(c))
	}
}

func PrebidHandler(w http.ResponseWriter, r *http.Request, rp httprouter.Params, c chan *PostPayloadChannel) {
	//fmt.Print(r.Header)
	//fmt.Println(r.Header.Get("Referer"))
	t := time.Now()
	ctx := appengine.NewContext(r)
	defer TimeTrack(ctx, c, t, "PrebidHandler")
	responseData, err := ioutil.ReadAll(r.Body)
	if err != nil {
		log.Warningf(ctx, "error: %v currentChannelLength: %v", err, len(c))
		Do204(w)
		return
	}

	c <- &PostPayloadChannel{
		responseData,
		&map[string]string{
			"referrer":  r.Referer(),
			"useragent": r.UserAgent(),
			"ip":        r.Header.Get("x-forwarded-for"),
		},
		ctx,
	}

	Do204(w)
}

func Do204(w http.ResponseWriter) {
	w.Header().Add("Access-Control-Allow-Credentials", "true")
	w.Header().Add("Access-Control-Allow-Headers", "Accept,Authorization,Cache-Control,Content-Type,"+
		"Keep-Alive,Origin,User-Agent,X-Requested-With")
	w.Header().Add("Access-Control-Allow-Methods", "POST")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	w.WriteHeader(204)
}

type GcsGzFileRoller struct {
	io.Writer
	client        *storage.Client
	bucket        string
	ctx           context.Context
	fileNameTmplt string
	instanceId    string

	dateStr         string
	hourStr         string
	dateHourStr     string
	isStreaming     bool
	filePathAndName string
	cBytesWritten   uint64
	uBytesWritten   uint64
	recordsWritten  uint64

	fi *storage.Writer
	gf *gzip.Writer
	fw *bufio.Writer
}

func (f *GcsGzFileRoller) Write(buf []byte) (int, error) {
	n, err := f.fi.Write(buf)
	atomic.AddUint64(&f.cBytesWritten, uint64(n))
	return n, err
}

func (f *GcsGzFileRoller) IncrementByteCount(size int) *GcsGzFileRoller {
	f.uBytesWritten += uint64(size)
	return f
}

func (f *GcsGzFileRoller) NextGZ() *GcsGzFileRoller {
	f.cBytesWritten = 0
	f.uBytesWritten = 0
	f.recordsWritten = 0

	tm := time.Now().UTC()
	f.dateStr = fmt.Sprintf("%d%02d%02d", tm.Year(), tm.Month(), tm.Day())
	f.hourStr = fmt.Sprintf("%02d", tm.Hour())
	f.dateHourStr = f.dateStr + "-" + f.hourStr
	fileName := fmt.Sprintf(f.fileNameTmplt, f.dateStr, f.dateHourStr, f.instanceId, tm.Unix())
	f.filePathAndName = fileName

	fi := f.client.Bucket(f.bucket).Object(fileName).NewWriter(f.ctx)
	f.fi = fi
	gf := gzip.NewWriter(f)
	nameArray := strings.Split(fileName, "/")
	gf.Name = nameArray[len(nameArray)-1]
	fw := bufio.NewWriter(gf)
	f.gf = gf
	f.fw = fw
	f.isStreaming = true
	return f
}

func (f *GcsGzFileRoller) WriteGZ(b *PostPayloadChannel, brf *GcsGzFileRoller, brfProtobuf *GcsGzFileRoller) *GcsGzFileRoller {
	var jsonMsg []byte
	payload := &serialize.LogPrebidEvents{}

	if err := proto.Unmarshal(b.msg, payload); err != nil {
		b64enc := b64.StdEncoding.EncodeToString(b.msg)
		log.Warningf(b.ctx, "can't deserialize protobuf payload, error: %v, request: %v, b64 payload: %v", err,
			b.reqAttrMap, b64enc)

		// this packages protobuf to base64 string, then to byte array, then write to badrec file stream
		LogJsonMsg(brfProtobuf, []byte(b64enc))

		return f
	}

	if rslt, err := ffjson.Marshal(payload); err == nil {
		jsonMsg = rslt
	} else {
		b64enc := b64.StdEncoding.EncodeToString(b.msg)
		log.Warningf(b.ctx, "can't json marshal protobuf payload, error: %v, request: %v, b64 payload: %v", err,
			b.reqAttrMap, b64enc)

		// this packages protobuf to base64 string, then to byte array, then write to badrec file stream
		LogJsonMsg(brfProtobuf, []byte(b64enc))
		return f
	}

	// call function to verify and validate timestamp and prebid_auction_id columns

	var writeRecord bool = VerifyFields(payload)

	if writeRecord == false {
		log.Errorf(f.ctx, "Field verification: %v", "Field verification has failed either for timestamp or prebid_auction_id")
		LogJsonMsg(brf, jsonMsg)
		return f
	}

	LogJsonMsg(f, jsonMsg)

	return f
}

func (f *GcsGzFileRoller) CloseCurrentGZ() *GcsGzFileRoller {
	f.fw.Flush()
	f.gf.Close()
	f.fi.Close()
	f.isStreaming = false
	return f
}

func (f *GcsGzFileRoller) GetStats() []byte {
	rslt, _ := ffjson.Marshal(&map[string]string{
		"isStreaming":              strconv.FormatBool(f.isStreaming),
		"bucket":                   f.bucket,
		"instanceId":               f.instanceId,
		"filePathAndName":          f.filePathAndName,
		"compressedBytesWritten":   strconv.FormatUint(f.cBytesWritten, 10),
		"uncompressedBytesWritten": strconv.FormatUint(f.uBytesWritten, 10),
		"recordsWritten":           strconv.FormatUint(f.recordsWritten, 10),
	})
	return rslt
}

func VerifyFields(prebidData *serialize.LogPrebidEvents) bool {
	var writeData bool = true
	if (*prebidData).Timestamp == 0 || (*prebidData).Auctions == nil {
		fmt.Println("timestamp or auctions field is missing in the record ")
		return false
	}
	timestampValue := strconv.FormatUint((*prebidData).Timestamp, 10)
	t, err := strconv.ParseInt(timestampValue, 10, 64)
	if err != nil {
		fmt.Println("timestamp parsing error : ", err)
		fmt.Println("Maximum value allowed for timestamp string is : ", t)
		return false
	}

	t = 0 // to avoid Go's error for unused variables

	for _, element := range (*prebidData).Auctions {
		if (*element).PrebidAuctionId == "" {
			writeData = false
			break
		}
	}
	return writeData
}

func LogJsonMsg(f *GcsGzFileRoller, msg []byte) {
	if !f.isStreaming {
		f.NextGZ()
	}
	tm := time.Now().UTC()
	dateHourStr := fmt.Sprintf("%d%02d%02d-%02d", tm.Year(), tm.Month(), tm.Day(), tm.Hour())
	if f.dateHourStr != dateHourStr || f.cBytesWritten >= 524288000 {
		log.Infof(f.ctx, "closing '%s' stream to roll to next hour or due to size (>=500MB)", f.filePathAndName)
		f.CloseCurrentGZ().NextGZ()
	}
	(f.fw).Write(msg)
	(f.fw).WriteString("\n")
	f.IncrementByteCount(len(msg) + NewLineBytes)
	f.recordsWritten++

}

func ConstructDict(dict map[string]string) string {
	str := "{\n"
	msgKeys := SortedKeys(dict)

	for _, key := range msgKeys {
		str = str + "\"" + key + "\":" + "\"" + dict[key] + "\",\n"
	}
	str = str[0:len(str)-2] + "\n}"
	return str
}

func SortedKeys(m map[string]string) []string {
	keys := make([]string, len(m))
	i := 0
	for k := range m {
		keys[i] = k
		i++
	}
	sort.Strings(keys)
	return keys
}
